Evaluation Notation

[C] - Camo
[B] - Blocking
[O] - Overlap
[T] - Tiny
[N] - Noisy
[D] - Dark
[0] - No Difficulty

If there are multiple difficulty categories on a single annotation, the difficulty
above all the applicable difficulties is selected (e.g. if [B], [O], and [D] is 
observable on a single nut, [B] is the selected notation).